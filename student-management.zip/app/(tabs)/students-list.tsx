import React, { useState, useCallback, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, Pressable, SafeAreaView, Alert, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import * as Haptics from 'expo-haptics';
import * as SystemUI from 'expo-system-ui';
import * as Print from 'expo-print';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import InputField from '@/components/ui/input-field';
import Toast from '@/components/ui/toast';
import { DatabaseService } from '@/data/database';
import { generatePDFHtml } from '@/data/pdfService';
import type { Student } from '@/data/types';

export default function StudentsListScreen() {
  const colors = useColors();
  const router = useRouter();
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('success');
  const [isExporting, setIsExporting] = useState(false);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const loadStudents = useCallback(async () => {
    const data = await DatabaseService.getAllStudents();
    setStudents(data);
    setFilteredStudents(data);
  }, []);

  useEffect(() => {
    loadStudents();
  }, [loadStudents]);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setFilteredStudents(students);
    } else {
      const lower = searchQuery.toLowerCase();
      const filtered = students.filter(s =>
        s.name.toLowerCase().includes(lower) ||
        s.idNumber.toLowerCase().includes(lower) ||
        s.governorate.toLowerCase().includes(lower) ||
        s.specialization.toLowerCase().includes(lower)
      );
      setFilteredStudents(filtered);
    }
  }, [searchQuery, students]);

  const handleExportPDF = async () => {
    if (filteredStudents.length === 0) {
      showToast('لا يوجد طلاب للتصدير', 'error');
      return;
    }

    setIsExporting(true);
    try {
      const html = generatePDFHtml(filteredStudents);
      
      // Generate PDF
      const { uri } = await Print.printToFileAsync({ html });
      const fileName = `students_report_${new Date().toISOString().replace(/[:.]/g, '-')}.pdf`;
      const destUri = `${FileSystem.documentDirectory}${fileName}`;
      await FileSystem.moveAsync({ from: uri, to: destUri });

      if (Platform.OS !== 'web' && await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(destUri, {
          mimeType: 'application/pdf',
          dialogTitle: 'مشاركة تقرير الطلاب',
        });
        showToast('تم إنشاء ملف PDF ومشاركته', 'success');
      } else {
        showToast(`تم حفظ ملف PDF بنجاح`, 'success');
      }

      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error: any) {
      console.error('PDF export error:', error);
      showToast('حدث خطأ أثناء إنشاء PDF', 'error');
    } finally {
      setIsExporting(false);
    }
  };

  const renderStudent = ({ item }: { item: Student }) => (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={styles.cardHeader}>
        <View style={[styles.idBadge, { backgroundColor: colors.primary }]}>
          <Text style={styles.idText}>#{item.id}</Text>
        </View>
        <Text style={[styles.studentName, { color: colors.foreground }]}>{item.name}</Text>
      </View>
      <View style={styles.cardDetails}>
        <Text style={[styles.cardDetail, { color: colors.muted }]}>
          <MaterialIcons name="badge" size={14} color={colors.muted} /> {item.idNumber}
        </Text>
        <Text style={[styles.cardDetail, { color: colors.muted }]}>
          <MaterialIcons name="location-on" size={14} color={colors.muted} /> {item.governorate}
        </Text>
        <Text style={[styles.cardDetail, { color: colors.muted }]}>
          <MaterialIcons name="school" size={14} color={colors.muted} /> {item.specialization}
        </Text>
        <Text style={[styles.cardDetail, { color: colors.muted }]}>
          <MaterialIcons name="class" size={14} color={colors.muted} /> {item.level}
        </Text>
        <Text style={[styles.cardDetail, { color: colors.muted }]}>
          <MaterialIcons name="phone" size={14} color={colors.muted} /> {item.phone}
        </Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Pressable
          style={[styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => router.back()}
        >
          <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
        </Pressable>
        <View style={[styles.headerIcon, { backgroundColor: '#8B5CF6' + '20' }]}>
          <MaterialIcons name="list" size={28} color="#8B5CF6" />
        </View>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>جميع الطلاب</Text>
      </View>

      {/* Search */}
      <View style={styles.searchSection}>
        <InputField
          label="بحث في القائمة"
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="ابحث بالاسم أو رقم الهوية..."
        />
      </View>

      {/* Stats */}
      <View style={[styles.statsBar, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Text style={[styles.statsText, { color: colors.foreground }]}>
          إجمالي: {filteredStudents.length} طالب
        </Text>
        {searchQuery ? (
          <Pressable onPress={() => setSearchQuery('')}>
            <Text style={[styles.clearSearch, { color: colors.primary }]}>مسح البحث</Text>
          </Pressable>
        ) : null}
      </View>

      {/* Student List */}
      <FlatList
        data={filteredStudents}
        renderItem={renderStudent}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={[styles.emptyState, { backgroundColor: colors.surface }]}>
            <MaterialIcons name="people-outline" size={64} color={colors.muted} />
            <Text style={[styles.emptyText, { color: colors.muted }]}>
              {searchQuery ? 'لا توجد نتائج' : 'لا يوجد طلاب مسجلين بعد'}
            </Text>
            <Text style={[styles.emptySubtext, { color: colors.muted }]}>
              {searchQuery ? 'جرب كلمة بحث أخرى' : 'أضف طلاب جدد من الشاشة الرئيسية'}
            </Text>
          </View>
        }
      />

      {/* Export Button */}
      {filteredStudents.length > 0 && (
        <View style={styles.bottomBar}>
          <Pressable
            style={({ pressed }) => [
              styles.exportButton,
              { backgroundColor: isExporting ? colors.muted : colors.primary },
              pressed && !isExporting && { opacity: 0.85 },
            ]}
            onPress={handleExportPDF}
            disabled={isExporting}
          >
            <MaterialIcons name={isExporting ? 'hourglass-empty' : 'picture-as-pdf'} size={20} color="#FFF" />
            <Text style={styles.exportButtonText}>
              {isExporting ? 'جاري التصدير...' : 'تصدير PDF'}
            </Text>
          </Pressable>
        </View>
      )}

      <Toast
        visible={toastVisible}
        message={toastMessage}
        type={toastType}
        onHide={() => setToastVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  backButton: { width: 40, height: 40, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  headerIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 20, fontWeight: '700', flex: 1, textAlign: 'right' },
  searchSection: { paddingHorizontal: 16, marginBottom: 12 },
  statsBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, marginHorizontal: 16, borderRadius: 10, borderWidth: 1, marginBottom: 8 },
  statsText: { fontSize: 14, fontWeight: '600' },
  clearSearch: { fontSize: 13, fontWeight: '600' },
  listContent: { paddingHorizontal: 16, paddingBottom: 100 },
  card: { borderRadius: 12, borderWidth: 1, padding: 14, marginBottom: 8 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8, gap: 10 },
  idBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6 },
  idText: { color: '#FFF', fontSize: 11, fontWeight: '700' },
  studentName: { fontSize: 17, fontWeight: '600', flex: 1, textAlign: 'right' },
  cardDetails: { gap: 4 },
  cardDetail: { fontSize: 13, textAlign: 'right', flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  emptyState: { padding: 40, borderRadius: 16, alignItems: 'center', marginTop: 20 },
  emptyText: { fontSize: 16, marginTop: 12, fontWeight: '600' },
  emptySubtext: { fontSize: 13, marginTop: 6 },
  bottomBar: { position: 'absolute', bottom: 20, left: 16, right: 16 },
  exportButton: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 12, gap: 10, elevation: 3 },
  exportButtonText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
