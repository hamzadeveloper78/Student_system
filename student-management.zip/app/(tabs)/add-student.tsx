import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Alert, SafeAreaView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import * as Haptics from 'expo-haptics';
import * as SystemUI from 'expo-system-ui';
import InputField from '@/components/ui/input-field';
import DropdownField from '@/components/ui/dropdown-field';
import Toast from '@/components/ui/toast';
import { DatabaseService } from '@/data/database';
import type { StudentFormData } from '@/data/types';

const ID_TYPES = ['بطاقة شخصية', 'جواز سفر', 'بطاقة تأمين', 'شهادة ميلاد', 'أخرى'];
const GOVERNORATES = [
  'أمانة العاصمة', 'عدن', 'الحديدة', 'تعز', 'إب', 'ذمار', 'المحويت',
  'حضرموت', 'شبوة', 'بيضاء', 'مأرب', 'الجوف', 'صعدة', 'عمران',
  'ضالع', 'لحج', 'أبين', 'المهرة', 'سقطرى', 'ريمه', 'صنعاء',
];
const LEVELS = [
  'المستوى الأول', 'المستوى الثاني', 'المستوى الثالث', 'المستوى الرابع',
  'المستوى الخامس', 'المستوى السادس', 'المستوى السابع', 'المستوى الثامن',
];
const SPECIALIZATIONS = [
  'علوم القرآن', 'الفقه', 'العقيدة', 'اللغة العربية', 'التاريخ الإسلامي',
  'الحديث الشريف', 'التفسير', 'الفلسفة', 'أخرى',
];

const emptyForm: StudentFormData = {
  name: '',
  idType: '',
  idNumber: '',
  governorate: '',
  district: '',
  village: '',
  isolation: '',
  specialization: '',
  level: '',
  phone: '',
};

export default function AddStudentScreen() {
  const colors = useColors();
  const router = useRouter();
  const [form, setForm] = useState<StudentFormData>(emptyForm);
  const [errors, setErrors] = useState<Partial<Record<keyof StudentFormData, string>>>({});
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('success');
  const [nextId, setNextId] = useState(0);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof StudentFormData, string>> = {};
    
    if (!form.name.trim()) newErrors.name = 'اسم الطالب مطلوب';
    if (!form.idType) newErrors.idType = 'نوع الهوية مطلوب';
    if (!form.idNumber.trim()) newErrors.idNumber = 'رقم الهوية مطلوب';
    if (!form.governorate) newErrors.governorate = 'المحافظة مطلوبة';
    if (!form.specialization) newErrors.specialization = 'التخصص مطلوب';
    if (!form.level) newErrors.level = 'المستوى مطلوب';
    if (!form.phone.trim()) newErrors.phone = 'رقم الهاتف مطلوب';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) {
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
      return;
    }

    try {
      const newStudent = await DatabaseService.addStudent(form);
      setNextId(prev => Math.max(prev, newStudent.id));
      showToast('تم حفظ بيانات الطالب بنجاح', 'success');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      // مسح الحقول بعد الحفظ
      setForm(emptyForm);
      setErrors({});
    } catch (error) {
      showToast('حدث خطأ أثناء الحفظ', 'error');
    }
  };

  const handleClear = () => {
    setForm(emptyForm);
    setErrors({});
    showToast('تم مسح جميع الحقول', 'info');
  };

  const updateField = (field: keyof StudentFormData, value: string) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Pressable
            style={[styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => router.back()}
          >
            <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
          </Pressable>
          <View style={[styles.headerIcon, { backgroundColor: '#10B981' + '20' }]}>
            <MaterialIcons name="person-add" size={28} color="#10B981" />
          </View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>إضافة طالب جديد</Text>
        </View>

        {/* Form */}
        <View style={[styles.formContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.formTitle, { color: colors.primary }]}>بيانات الطالب</Text>
          
          {/* رقم الطالب التلقائي */}
          <View style={styles.autoIdContainer}>
            <Text style={[styles.autoIdLabel, { color: colors.muted }]}>الرقم التعريفي</Text>
            <View style={[styles.autoIdValue, { backgroundColor: colors.primary + '10', borderColor: colors.primary }]}>
              <Text style={[styles.autoIdText, { color: colors.primary }]}>
                سيتم إنشاؤه تلقائياً عند الحفظ
              </Text>
            </View>
          </View>

          <InputField
            label="اسم الطالب"
            value={form.name}
            onChangeText={(text) => updateField('name', text)}
            placeholder="أدخل اسم الطالب الثلاثي"
            error={errors.name}
            required
          />

          <DropdownField
            label="نوع الهوية"
            value={form.idType}
            options={ID_TYPES}
            onSelect={(value) => updateField('idType', value)}
            error={errors.idType}
            required
          />

          <InputField
            label="رقم الهوية"
            value={form.idNumber}
            onChangeText={(text) => updateField('idNumber', text)}
            placeholder="أدخل رقم الهوية"
            keyboardType="numeric"
            error={errors.idNumber}
            required
          />

          <DropdownField
            label="المحافظة"
            value={form.governorate}
            options={GOVERNORATES}
            onSelect={(value) => updateField('governorate', value)}
            error={errors.governorate}
            required
          />

          <InputField
            label="المديرية"
            value={form.district}
            onChangeText={(text) => updateField('district', text)}
            placeholder="أدخل اسم المديرية"
          />

          <InputField
            label="القرية"
            value={form.village}
            onChangeText={(text) => updateField('village', text)}
            placeholder="أدخل اسم القرية"
          />

          <InputField
            label="العزلة"
            value={form.isolation}
            onChangeText={(text) => updateField('isolation', text)}
            placeholder="أدخل اسم العزلة"
          />

          <DropdownField
            label="التخصص"
            value={form.specialization}
            options={SPECIALIZATIONS}
            onSelect={(value) => updateField('specialization', value)}
            error={errors.specialization}
            required
          />

          <DropdownField
            label="المستوى"
            value={form.level}
            options={LEVELS}
            onSelect={(value) => updateField('level', value)}
            error={errors.level}
            required
          />

          <InputField
            label="رقم الهاتف"
            value={form.phone}
            onChangeText={(text) => updateField('phone', text)}
            placeholder="07xxxxxxxx"
            keyboardType="phone-pad"
            error={errors.phone}
            required
          />
        </View>

        {/* Buttons */}
        <View style={styles.buttonsContainer}>
          <Pressable
            style={({ pressed }) => [
              styles.saveButton,
              { backgroundColor: colors.primary },
              pressed && styles.buttonPressed,
            ]}
            onPress={handleSave}
          >
            <MaterialIcons name="save" size={20} color="#FFF" />
            <Text style={styles.saveButtonText}>حفظ الطالب</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.clearButton,
              { backgroundColor: colors.warning + '15', borderColor: colors.warning },
              pressed && styles.buttonPressed,
            ]}
            onPress={handleClear}
          >
            <MaterialIcons name="clear" size={20} color={colors.warning} />
            <Text style={[styles.clearButtonText, { color: colors.warning }]}>مسح الحقول</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.backButtonBottom,
              { backgroundColor: colors.surface, borderColor: colors.border },
              pressed && styles.buttonPressed,
            ]}
            onPress={() => router.back()}
          >
            <MaterialIcons name="arrow-back" size={20} color={colors.muted} />
            <Text style={[styles.backButtonText, { color: colors.muted }]}>رجوع</Text>
          </Pressable>
        </View>
      </ScrollView>

      <Toast
        visible={toastVisible}
        message={toastMessage}
        type={toastType}
        onHide={() => setToastVisible(false)}
      />
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    gap: 12,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    flex: 1,
    textAlign: 'right',
  },
  formContainer: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 20,
  },
  formTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 16,
    textAlign: 'right',
  },
  autoIdContainer: {
    marginBottom: 16,
  },
  autoIdLabel: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
  },
  autoIdValue: {
    borderWidth: 1.5,
    borderRadius: 10,
    padding: 12,
  },
  autoIdText: {
    fontSize: 14,
    textAlign: 'center',
  },
  buttonsContainer: {
    gap: 12,
  },
  saveButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    gap: 10,
    elevation: 3,
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '700',
  },
  clearButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    gap: 10,
  },
  clearButtonText: {
    fontSize: 16,
    fontWeight: '700',
  },
  backButtonBottom: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    gap: 10,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: '600',
  },
  buttonPressed: {
    opacity: 0.85,
    transform: [{ scale: 0.98 }],
  },
});
