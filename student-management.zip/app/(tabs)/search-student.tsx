import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, FlatList, SafeAreaView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import * as Haptics from 'expo-haptics';
import * as SystemUI from 'expo-system-ui';
import InputField from '@/components/ui/input-field';
import DropdownField from '@/components/ui/dropdown-field';
import Toast from '@/components/ui/toast';
import AlertDialog from '@/components/ui/alert-dialog';
import { DatabaseService } from '@/data/database';
import type { Student, StudentFormData } from '@/data/types';

const ID_TYPES = ['بطاقة شخصية', 'جواز سفر', 'بطاقة تأمين', 'شهادة ميلاد', 'أخرى'];
const GOVERNORATES = [
  'أمانة العاصمة', 'عدن', 'الحديدة', 'تعز', 'إب', 'ذمار', 'المحويت',
  'حضرموت', 'شبوة', 'بيضاء', 'مأرب', 'الجوف', 'صعدة', 'عمران',
  'ضالع', 'لحج', 'أبين', 'المهرة', 'سقطرى', 'ريمه', 'صنعاء',
];
const LEVELS = [
  'المستوى الأول', 'المستوى الثاني', 'المستوى الثالث', 'المستوى الرابع',
  'المستوى الخامس', 'المستوى السادس', 'المستوى السابع', 'المستوى الثامن',
];
const SPECIALIZATIONS = [
  'علوم القرآن', 'الفقه', 'العقيدة', 'اللغة العربية', 'التاريخ الإسلامي',
  'الحديث الشريف', 'التفسير', 'الفلسفة', 'أخرى',
];

export default function SearchStudentScreen() {
  const colors = useColors();
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Student[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [showDeleteAlert, setShowDeleteAlert] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('success');
  const [editErrors, setEditErrors] = useState<Partial<Record<keyof StudentFormData, string>>>({});

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      showToast('يرجى إدخال اسم أو رقم هوية للبحث', 'error');
      return;
    }
    const results = await DatabaseService.searchStudents(searchQuery);
    setSearchResults(results);
    setHasSearched(true);
    setSelectedStudent(null);
    setIsEditing(false);

    if (results.length === 0) {
      showToast('لم يتم العثور على نتائج', 'info');
    }
  };

  const handleSelectStudent = (student: Student) => {
    setSelectedStudent(student);
    setIsEditing(false);
    setEditErrors({});
  };

  const handleDelete = async () => {
    if (!selectedStudent) return;
    try {
      await DatabaseService.deleteStudent(selectedStudent.id);
      setShowDeleteAlert(false);
      showToast('تم حذف الطالب بنجاح', 'success');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      // Refresh search
      handleSearch();
    } catch (error) {
      showToast('حدث خطأ أثناء الحذف', 'error');
    }
  };

  const startEditing = () => {
    setIsEditing(true);
    setEditErrors({});
  };

  const cancelEditing = () => {
    setIsEditing(false);
    setEditErrors({});
  };

  const updateEditField = (field: keyof Student, value: string) => {
    if (!selectedStudent) return;
    setSelectedStudent(prev => prev ? { ...prev, [field]: value } : null);
    if (editErrors[field as keyof StudentFormData]) {
      setEditErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field as keyof StudentFormData];
        return newErrors;
      });
    }
  };

  const saveEdit = async () => {
    if (!selectedStudent) return;

    const newErrors: Partial<Record<keyof StudentFormData, string>> = {};
    if (!selectedStudent.name.trim()) newErrors.name = 'اسم الطالب مطلوب';
    if (!selectedStudent.idType) newErrors.idType = 'نوع الهوية مطلوب';
    if (!selectedStudent.idNumber.trim()) newErrors.idNumber = 'رقم الهوية مطلوب';
    if (!selectedStudent.governorate) newErrors.governorate = 'المحافظة مطلوبة';
    if (!selectedStudent.specialization) newErrors.specialization = 'التخصص مطلوب';
    if (!selectedStudent.level) newErrors.level = 'المستوى مطلوب';
    if (!selectedStudent.phone.trim()) newErrors.phone = 'رقم الهاتف مطلوب';

    if (Object.keys(newErrors).length > 0) {
      setEditErrors(newErrors);
      showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
      return;
    }

    try {
      const { id, createdAt, ...updates } = selectedStudent;
      await DatabaseService.updateStudent(id, updates);
      setIsEditing(false);
      showToast('تم تحديث بيانات الطالب بنجاح', 'success');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      showToast('حدث خطأ أثناء التحديث', 'error');
    }
  };

  const renderSearchResult = ({ item }: { item: Student }) => (
    <Pressable
      style={({ pressed }) => [
        styles.resultItem,
        { backgroundColor: colors.surface, borderColor: colors.border },
        pressed && { opacity: 0.7 },
        selectedStudent?.id === item.id && { backgroundColor: colors.primary + '10', borderColor: colors.primary },
      ]}
      onPress={() => handleSelectStudent(item)}
    >
      <Text style={[styles.resultName, { color: colors.foreground }]}>{item.name}</Text>
      <Text style={[styles.resultDetail, { color: colors.muted }]}>{item.idNumber} | {item.governorate}</Text>
    </Pressable>
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Pressable
            style={[styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => router.back()}
          >
            <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
          </Pressable>
          <View style={[styles.headerIcon, { backgroundColor: '#3B82F6' + '20' }]}>
            <MaterialIcons name="search" size={28} color="#3B82F6" />
          </View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>البحث والتعديل</Text>
        </View>

        {/* Search Section */}
        <View style={[styles.searchContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <InputField
            label="البحث عن طالب"
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="أدخل اسم الطالب أو رقم الهوية"
          />
          <Pressable
            style={({ pressed }) => [
              styles.searchButton,
              { backgroundColor: colors.primary },
              pressed && { opacity: 0.85 },
            ]}
            onPress={handleSearch}
          >
            <MaterialIcons name="search" size={20} color="#FFF" />
            <Text style={styles.searchButtonText}>بحث</Text>
          </Pressable>
        </View>

        {/* Search Results */}
        {hasSearched && !selectedStudent && (
          <View style={styles.resultsContainer}>
            <Text style={[styles.resultsTitle, { color: colors.foreground }]}>
              نتائج البحث ({searchResults.length})
            </Text>
            {searchResults.length > 0 ? (
              <FlatList
                data={searchResults}
                renderItem={renderSearchResult}
                keyExtractor={(item) => item.id.toString()}
                style={{ maxHeight: 300 }}
                showsVerticalScrollIndicator={false}
              />
            ) : (
              <View style={[styles.emptyState, { backgroundColor: colors.surface }]}>
                <MaterialIcons name="person-off" size={48} color={colors.muted} />
                <Text style={[styles.emptyText, { color: colors.muted }]}>لا توجد نتائج</Text>
              </View>
            )}
          </View>
        )}

        {/* Selected Student - Display/Edit Mode */}
        {selectedStudent && (
          <View style={[styles.studentDetail, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.detailHeader}>
              <Text style={[styles.detailName, { color: colors.foreground }]}>{selectedStudent.name}</Text>
              <Text style={[styles.detailId, { color: colors.primary }]}>#{selectedStudent.id}</Text>
            </View>

            {isEditing ? (
              <View style={styles.editForm}>
                <Text style={[styles.formTitle, { color: colors.warning }]}>تعديل البيانات</Text>
                <InputField
                  label="اسم الطالب"
                  value={selectedStudent.name}
                  onChangeText={(text) => updateEditField('name', text)}
                  error={editErrors.name}
                  required
                />
                <DropdownField
                  label="نوع الهوية"
                  value={selectedStudent.idType}
                  options={ID_TYPES}
                  onSelect={(value) => updateEditField('idType', value)}
                  error={editErrors.idType}
                  required
                />
                <InputField
                  label="رقم الهوية"
                  value={selectedStudent.idNumber}
                  onChangeText={(text) => updateEditField('idNumber', text)}
                  keyboardType="numeric"
                  error={editErrors.idNumber}
                  required
                />
                <DropdownField
                  label="المحافظة"
                  value={selectedStudent.governorate}
                  options={GOVERNORATES}
                  onSelect={(value) => updateEditField('governorate', value)}
                  error={editErrors.governorate}
                  required
                />
                <InputField
                  label="المديرية"
                  value={selectedStudent.district}
                  onChangeText={(text) => updateEditField('district', text)}
                />
                <InputField
                  label="القرية"
                  value={selectedStudent.village}
                  onChangeText={(text) => updateEditField('village', text)}
                />
                <InputField
                  label="العزلة"
                  value={selectedStudent.isolation}
                  onChangeText={(text) => updateEditField('isolation', text)}
                />
                <DropdownField
                  label="التخصص"
                  value={selectedStudent.specialization}
                  options={SPECIALIZATIONS}
                  onSelect={(value) => updateEditField('specialization', value)}
                  error={editErrors.specialization}
                  required
                />
                <DropdownField
                  label="المستوى"
                  value={selectedStudent.level}
                  options={LEVELS}
                  onSelect={(value) => updateEditField('level', value)}
                  error={editErrors.level}
                  required
                />
                <InputField
                  label="رقم الهاتف"
                  value={selectedStudent.phone}
                  onChangeText={(text) => updateEditField('phone', text)}
                  keyboardType="phone-pad"
                  error={editErrors.phone}
                  required
                />

                <View style={styles.editButtons}>
                  <Pressable
                    style={({ pressed }) => [
                      styles.saveEditButton,
                      { backgroundColor: colors.success },
                      pressed && { opacity: 0.85 },
                    ]}
                    onPress={saveEdit}
                  >
                    <MaterialIcons name="save" size={20} color="#FFF" />
                    <Text style={styles.editButtonText}>حفظ التعديلات</Text>
                  </Pressable>
                  <Pressable
                    style={({ pressed }) => [
                      styles.cancelEditButton,
                      { backgroundColor: colors.border },
                      pressed && { opacity: 0.85 },
                    ]}
                    onPress={cancelEditing}
                  >
                    <MaterialIcons name="close" size={20} color={colors.muted} />
                    <Text style={{ color: colors.muted, fontWeight: '600' }}>إلغاء</Text>
                  </Pressable>
                </View>
              </View>
            ) : (
              <View style={styles.viewForm}>
                <InfoRow icon="badge" label="رقم الهوية" value={selectedStudent.idNumber} />
                <InfoRow icon="location-on" label="المحافظة" value={selectedStudent.governorate} />
                <InfoRow icon="location-city" label="المديرية" value={selectedStudent.district} />
                <InfoRow icon="home" label="القرية" value={selectedStudent.village} />
                <InfoRow icon="location-on" label="العزلة" value={selectedStudent.isolation} />
                <InfoRow icon="school" label="التخصص" value={selectedStudent.specialization} />
                <InfoRow icon="class" label="المستوى" value={selectedStudent.level} />
                <InfoRow icon="phone" label="الهاتف" value={selectedStudent.phone} />
                <InfoRow icon="event" label="تاريخ الإضافة" value={new Date(selectedStudent.createdAt).toLocaleDateString('ar-EG')} />

                <View style={styles.actionButtons}>
                  <Pressable
                    style={({ pressed }) => [
                      styles.actionButton,
                      { backgroundColor: colors.warning + '15', borderColor: colors.warning },
                      pressed && { opacity: 0.85 },
                    ]}
                    onPress={startEditing}
                  >
                    <MaterialIcons name="edit" size={20} color={colors.warning} />
                    <Text style={{ color: colors.warning, fontWeight: '600' }}>تعديل</Text>
                  </Pressable>
                  <Pressable
                    style={({ pressed }) => [
                      styles.actionButton,
                      { backgroundColor: colors.error + '15', borderColor: colors.error },
                      pressed && { opacity: 0.85 },
                    ]}
                    onPress={() => setShowDeleteAlert(true)}
                  >
                    <MaterialIcons name="delete" size={20} color={colors.error} />
                    <Text style={{ color: colors.error, fontWeight: '600' }}>حذف</Text>
                  </Pressable>
                </View>
              </View>
            )}
          </View>
        )}
      </ScrollView>

      <Toast
        visible={toastVisible}
        message={toastMessage}
        type={toastType}
        onHide={() => setToastVisible(false)}
      />

      <AlertDialog
        visible={showDeleteAlert}
        title="تأكيد الحذف"
        message={`هل أنت متأكد من حذف الطالب "${selectedStudent?.name}"؟ هذا الإجراء لا يمكن التراجع عنه.`}
        onConfirm={handleDelete}
        onCancel={() => setShowDeleteAlert(false)}
        confirmText="حذف"
        cancelText="إلغاء"
        type="danger"
      />
    </SafeAreaView>
  );
}

function InfoRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.infoRow}>
      <MaterialIcons name={icon as any} size={20} color={colors.primary} />
      <Text style={[styles.infoLabel, { color: colors.muted }]}>{label}:</Text>
      <Text style={[styles.infoValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}


const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 20, gap: 12 },
  backButton: { width: 40, height: 40, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  headerIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 20, fontWeight: '700', flex: 1, textAlign: 'right' },
  searchContainer: { borderRadius: 16, borderWidth: 1, padding: 16, marginBottom: 16 },
  searchButton: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderRadius: 10, gap: 8 },
  searchButtonText: { color: '#FFF', fontSize: 15, fontWeight: '600' },
  resultsContainer: { marginBottom: 16 },
  resultsTitle: { fontSize: 15, fontWeight: '600', marginBottom: 8, textAlign: 'right' },
  resultItem: { padding: 14, borderRadius: 10, borderWidth: 1, marginBottom: 6 },
  resultName: { fontSize: 16, fontWeight: '600', textAlign: 'right', marginBottom: 4 },
  resultDetail: { fontSize: 13, textAlign: 'right' },
  emptyState: { padding: 30, borderRadius: 12, alignItems: 'center' },
  emptyText: { fontSize: 15, marginTop: 10 },
  studentDetail: { borderRadius: 16, borderWidth: 1, padding: 16 },
  detailHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' },
  detailName: { fontSize: 20, fontWeight: '700', flex: 1, textAlign: 'right' },
  detailId: { fontSize: 14, fontWeight: '600', backgroundColor: '#1A3A6B15', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  editForm: { marginTop: 8 },
  viewForm: { gap: 8 },
  infoRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 0.5, borderBottomColor: '#E5E7EB' },
  infoLabel: { fontSize: 14, flex: 0.5, textAlign: 'right' },
  infoValue: { fontSize: 14, fontWeight: '500', flex: 1, textAlign: 'right' },
  formTitle: { fontSize: 16, fontWeight: '700', marginBottom: 12, textAlign: 'right' },
  editButtons: { flexDirection: 'row-reverse', gap: 10, marginTop: 16 },
  saveEditButton: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderRadius: 10, gap: 8 },
  editButtonText: { color: '#FFF', fontSize: 14, fontWeight: '600' },
  cancelEditButton: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderRadius: 10, gap: 8 },
  actionButtons: { flexDirection: 'row-reverse', gap: 12, marginTop: 16 },
  actionButton: { flex: 1, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, borderRadius: 10, borderWidth: 1.5, gap: 8 },
});
