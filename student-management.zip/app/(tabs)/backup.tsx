import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, Pressable, SafeAreaView, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import * as Haptics from 'expo-haptics';
import * as SystemUI from 'expo-system-ui';
import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import Toast from '@/components/ui/toast';
import AlertDialog from '@/components/ui/alert-dialog';
import { DatabaseService } from '@/data/database';

export default function BackupScreen() {
  const colors = useColors();
  const router = useRouter();
  const [isCreating, setIsCreating] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [showRestoreConfirm, setShowRestoreConfirm] = useState(false);
  const [toastVisible, setToastVisible] = useState(false);
  const [toastMessage, setToastMessage] = useState('');
  const [toastType, setToastType] = useState<'success' | 'error' | 'info'>('success');
  const [studentCount, setStudentCount] = useState(0);
  const [lastBackupInfo, setLastBackupInfo] = useState<{ time: string; count: number } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setToastVisible(true);
  };

  const loadCount = useCallback(async () => {
    const students = await DatabaseService.getAllStudents();
    setStudentCount(students.length);
  }, []);

  // Load count on mount
  React.useEffect(() => {
    loadCount();
  }, [loadCount]);

  const handleCreateBackup = async () => {
    setIsCreating(true);
    try {
      const backupJson = await DatabaseService.createBackup();
      const students = await DatabaseService.getAllStudents();
      
      // Save backup file to device
      const fileName = `student_backup_${new Date().toISOString().replace(/[:.]/g, '-')}.json`;
      const fileUri = `${FileSystem.documentDirectory}${fileName}`;
      await FileSystem.writeAsStringAsync(fileUri, backupJson);

      setLastBackupInfo({
        time: new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
        count: students.length,
      });

      // Share backup file
      if (Platform.OS !== 'web' && await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'application/json',
          dialogTitle: 'مشاركة النسخة الاحتياطية',
        });
      }

      showToast(`تم إنشاء النسخة الاحتياطية بنجاح (${students.length} طالب)`, 'success');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      await loadCount();
    } catch (error: any) {
      console.error('Backup error:', error);
      showToast('حدث خطأ أثناء إنشاء النسخة الاحتياطية', 'error');
    } finally {
      setIsCreating(false);
    }
  };

  const handleImportBackup = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/json', '.json'],
        copyToCacheDirectory: true,
      });

      if (result.canceled || !result.assets?.length) {
        showToast('تم إلغاء اختيار الملف', 'info');
        return;
      }

      const fileUri = result.assets[0].uri;
      const fileContent = await FileSystem.readAsStringAsync(fileUri);
      const data = JSON.parse(fileContent);

      if (!data.data || !Array.isArray(data.data)) {
        showToast('ملف النسخة الاحتياطية غير صالح', 'error');
        return;
      }

      // Show confirmation
      setShowRestoreConfirm(true);
      // Store the file content temporarily
      (globalThis as any).__restoreData = fileContent;
    } catch (error: any) {
      console.error('Import error:', error);
      if (error.message !== 'User canceled document selection') {
        showToast('حدث خطأ أثناء استيراد الملف', 'error');
      }
    }
  };

  const confirmRestore = async () => {
    setShowRestoreConfirm(false);
    setIsRestoring(true);
    try {
      const fileContent = (globalThis as any).__restoreData;
      if (!fileContent) {
        showToast('لا يوجد بيانات للاستعادة', 'error');
        return;
      }

      const count = await DatabaseService.restoreBackup(fileContent);
      showToast(`تم استعادة ${count} طالب بنجاح`, 'success');
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      await loadCount();
    } catch (error: any) {
      console.error('Restore error:', error);
      showToast('حدث خطأ أثناء استعادة النسخة الاحتياطية', 'error');
    } finally {
      setIsRestoring(false);
      delete (globalThis as any).__restoreData;
    }
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Pressable
          style={[styles.backButton, { backgroundColor: colors.surface, borderColor: colors.border }]}
          onPress={() => router.back()}
        >
          <MaterialIcons name="arrow-back" size={24} color={colors.foreground} />
        </Pressable>
        <View style={[styles.headerIcon, { backgroundColor: '#F59E0B' + '20' }]}>
          <MaterialIcons name="backup" size={28} color="#F59E0B" />
        </View>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>النسخ الاحتياطي</Text>
      </View>

      {/* Stats Card */}
      <View style={[styles.statsCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <MaterialIcons name="storage" size={32} color={colors.primary} />
        <View style={styles.statsInfo}>
          <Text style={[styles.statsCount, { color: colors.foreground }]}>{studentCount}</Text>
          <Text style={[styles.statsLabel, { color: colors.muted }]}>طالب مسجل في النظام</Text>
        </View>
      </View>

      {/* Last Backup Info */}
      {lastBackupInfo && (
        <View style={[styles.infoCard, { backgroundColor: colors.success + '10', borderColor: colors.success }]}>
          <MaterialIcons name="check-circle" size={24} color={colors.success} />
          <View style={styles.infoContent}>
            <Text style={[styles.infoTitle, { color: colors.foreground }]}>آخر نسخة احتياطية</Text>
            <Text style={[styles.infoText, { color: colors.muted }]}>{lastBackupInfo.time}</Text>
            <Text style={[styles.infoText, { color: colors.muted }]}>{lastBackupInfo.count} طالب</Text>
          </View>
        </View>
      )}

      {/* Actions */}
      <View style={styles.actionsContainer}>
        <Pressable
          style={({ pressed }) => [
            styles.actionCard,
            { backgroundColor: colors.surface, borderColor: colors.border },
            pressed && { opacity: 0.85 },
          ]}
          onPress={handleCreateBackup}
          disabled={isCreating}
        >
          <View style={[styles.actionIcon, { backgroundColor: '#10B981' + '15' }]}>
            <MaterialIcons name={isCreating ? 'hourglass-empty' : 'cloud-upload'} size={36} color="#10B981" />
          </View>
          <Text style={[styles.actionTitle, { color: colors.foreground }]}>إنشاء نسخة احتياطية</Text>
          <Text style={[styles.actionSubtitle, { color: colors.muted }]}>
            {isCreating ? 'جاري الإنشاء...' : 'حفظ جميع بيانات الطلاب في ملف'}
          </Text>
        </Pressable>

        <Pressable
          style={({ pressed }) => [
            styles.actionCard,
            { backgroundColor: colors.surface, borderColor: colors.border },
            pressed && { opacity: 0.85 },
          ]}
          onPress={handleImportBackup}
          disabled={isRestoring}
        >
          <View style={[styles.actionIcon, { backgroundColor: '#3B82F6' + '15' }]}>
            <MaterialIcons name={isRestoring ? 'hourglass-empty' : 'cloud-download'} size={36} color="#3B82F6" />
          </View>
          <Text style={[styles.actionTitle, { color: colors.foreground }]}>استيراد نسخة احتياطية</Text>
          <Text style={[styles.actionSubtitle, { color: colors.muted }]}>
            {isRestoring ? 'جاري الاستعادة...' : 'استعادة البيانات من ملف نسخة احتياطية'}
          </Text>
        </Pressable>
      </View>

      <Toast
        visible={toastVisible}
        message={toastMessage}
        type={toastType}
        onHide={() => setToastVisible(false)}
      />

      <AlertDialog
        visible={showRestoreConfirm}
        title="تأكيد الاستعادة"
        message="سيتم استبدال جميع البيانات الحالية بالبيانات من النسخة الاحتياطية. هل أنت متأكد؟"
        onConfirm={confirmRestore}
        onCancel={() => setShowRestoreConfirm(false)}
        confirmText="استعادة"
        cancelText="إلغاء"
        type="danger"
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 12 },
  backButton: { width: 40, height: 40, borderRadius: 10, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  headerIcon: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 20, fontWeight: '700', flex: 1, textAlign: 'right' },
  statsCard: { flexDirection: 'row-reverse', alignItems: 'center', padding: 20, margin: 16, borderRadius: 16, borderWidth: 1, gap: 16 },
  statsInfo: { flex: 1, alignItems: 'flex-start' },
  statsCount: { fontSize: 28, fontWeight: '800', textAlign: 'right' },
  statsLabel: { fontSize: 14, textAlign: 'right' },
  infoCard: { flexDirection: 'row-reverse', alignItems: 'center', padding: 16, marginHorizontal: 16, borderRadius: 12, borderWidth: 1, gap: 12, marginBottom: 16 },
  infoContent: { flex: 1, gap: 2 },
  infoTitle: { fontSize: 15, fontWeight: '600', textAlign: 'right' },
  infoText: { fontSize: 13, textAlign: 'right' },
  actionsContainer: { gap: 14, paddingHorizontal: 16 },
  actionCard: { borderRadius: 16, borderWidth: 1, padding: 20, alignItems: 'center' },
  actionIcon: { width: 72, height: 72, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  actionTitle: { fontSize: 17, fontWeight: '700', marginBottom: 4, textAlign: 'center' },
  actionSubtitle: { fontSize: 13, textAlign: 'center', lineHeight: 18 },
});
