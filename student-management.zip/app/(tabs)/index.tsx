import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, SafeAreaView, Pressable } from 'react-native';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import { DatabaseService } from '@/data/database';
import * as SystemUI from 'expo-system-ui';
import { useRouter } from 'expo-router';

interface MenuCardProps {
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  href: string;
}

function MenuCard({ title, subtitle, icon, color, href }: MenuCardProps) {
  const colors = useColors();
  const router = useRouter();

  return (
    <Pressable
      onPress={() => router.push(href as any)}
      style={({ pressed }: { pressed: boolean }) => [
        styles.card,
        { backgroundColor: colors.surface },
        pressed && { opacity: 0.85, transform: [{ scale: 0.98 }] },
      ]}>
        <View style={[styles.iconContainer, { backgroundColor: color + '15' }]}>
          <MaterialIcons name={icon as any} size={32} color={color} />
        </View>
        <Text style={[styles.cardTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.cardSubtitle, { color: colors.muted }]}>{subtitle}</Text>
      </Pressable>
  );
}

export default function HomeScreen() {
  const colors = useColors();
  const [studentCount, setStudentCount] = useState(0);

  useEffect(() => {
    loadStudentCount();
  }, []);

  const loadStudentCount = async () => {
    const students = await DatabaseService.getAllStudents();
    setStudentCount(students.length);
  };

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={[styles.logoContainer, { backgroundColor: colors.primary }]}>
            <MaterialIcons name="school" size={36} color="#FFF" />
          </View>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            نظام إدارة الطلاب
          </Text>
          <Text style={[styles.headerSubtitle, { color: colors.muted }]}>
            إدارة بيانات الطلاب بكل سهولة
          </Text>
        </View>

        {/* Stats Card */}
        <View style={[styles.statsCard, { backgroundColor: colors.primary }]}>
          <View style={styles.statsContent}>
            <Text style={[styles.statsCount, { color: '#FFF' }]}>
              {studentCount}
            </Text>
            <Text style={[styles.statsLabel, { color: '#FFF' }]}>
              طالب مسجل
            </Text>
          </View>
        </View>

        {/* Menu Cards */}
        <View style={styles.menuGrid}>
          <MenuCard
            title="إضافة طالب"
            subtitle="تسجيل بيانات طالب جديد"
            icon="person-add"
            color="#10B981"
            href="/(tabs)/add-student"
          />
          <MenuCard
            title="بحث وتعديل"
            subtitle="البحث عن طالب وتعديل بياناته"
            icon="search"
            color="#3B82F6"
            href="/(tabs)/search-student"
          />
          <MenuCard
            title="عرض الطلاب"
            subtitle="قائمة الطلاب وتصدير PDF"
            icon="list"
            color="#8B5CF6"
            href="/(tabs)/students-list"
          />
          <MenuCard
            title="نسخ احتياطي"
            subtitle="حفظ واستعادة البيانات"
            icon="backup"
            color="#F59E0B"
            href="/(tabs)/backup"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 24,
    marginTop: 10,
  },
  logoContainer: {
    width: 72,
    height: 72,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    elevation: 4,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 6,
    textAlign: 'center',
  },
  headerSubtitle: {
    fontSize: 15,
    textAlign: 'center',
  },
  statsCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    elevation: 3,
  },
  statsContent: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  statsCount: {
    fontSize: 36,
    fontWeight: '800',
  },
  statsLabel: {
    fontSize: 16,
    opacity: 0.9,
  },
  menuGrid: {
    gap: 14,
  },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    alignItems: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
  },
  iconContainer: {
    width: 64,
    height: 64,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center',
  },
  cardSubtitle: {
    fontSize: 13,
    textAlign: 'center',
  },
});
