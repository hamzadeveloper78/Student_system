import { DarkTheme, DefaultTheme, ThemeProvider } from "@react-navigation/native";
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { useEffect } from "react";
import "react-native-reanimated";

import { useColorScheme } from "@/hooks/use-color-scheme";
import * as SystemUI from "expo-system-ui";

export default function RootLayout() {
  const colorScheme = useColorScheme();

  useEffect(() => {
    SystemUI.setBackgroundColorAsync(colorScheme === "dark" ? "#000000" : "#FFFFFF");
  }, [colorScheme]);

  return (
    <ThemeProvider value={colorScheme === "dark" ? DarkTheme : DefaultTheme}>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="(tabs)/add-student" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)/search-student" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)/students-list" options={{ headerShown: false }} />
        <Stack.Screen name="(tabs)/backup" options={{ headerShown: false }} />
        <Stack.Screen name="oauth/callback" />
      </Stack>
      <StatusBar style={colorScheme === "dark" ? "light" : "dark"} />
    </ThemeProvider>
  );
}
