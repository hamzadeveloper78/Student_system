import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface DropdownFieldProps {
  label: string;
  value: string;
  options: string[];
  onSelect: (value: string) => void;
  placeholder?: string;
  error?: string;
  required?: boolean;
}

export default function DropdownField({
  label,
  value,
  options,
  onSelect,
  placeholder = 'اختر',
  error,
  required = false,
}: DropdownFieldProps) {
  const colors = useColors();
  const [isOpen, setIsOpen] = useState(false);

  const selectedLabel = value || placeholder;

  return (
    <View style={styles.container}>
      <Text style={[styles.label, { color: colors.foreground }]}>
        {label}
        {required && <Text style={{ color: colors.error }}> *</Text>}
      </Text>
      <Pressable
        style={[
          styles.dropdown,
          {
            borderColor: error ? colors.error : colors.border,
            backgroundColor: colors.surface,
          },
        ]}
        onPress={() => setIsOpen(!isOpen)}
      >
        <Text style={[styles.selectedText, { color: value ? colors.foreground : colors.muted }]}>
          {selectedLabel}
        </Text>
        <MaterialIcons name="expand-more" size={24} color={colors.muted} />
      </Pressable>
      {error ? (
        <Text style={[styles.errorText, { color: colors.error }]}>{error}</Text>
      ) : null}
      
      {isOpen && (
        <View style={[
          styles.dropdownList,
          { backgroundColor: colors.surface, borderColor: colors.border },
        ]}>
          <ScrollView style={{ maxHeight: 200 }}>
            {options.map((option) => (
              <Pressable
                key={option}
                style={[
                  styles.dropdownItem,
                  { borderBottomColor: colors.border },
                  value === option && { backgroundColor: colors.primary + '15' },
                ]}
                onPress={() => {
                  onSelect(option);
                  setIsOpen(false);
                }}
              >
                <Text style={[
                  styles.dropdownItemText,
                  { color: colors.foreground },
                  value === option && { color: colors.primary, fontWeight: '700' },
                ]}>
                  {option}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
  },
  dropdown: {
    borderWidth: 1.5,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    minHeight: 48,
  },
  selectedText: {
    fontSize: 15,
    flex: 1,
    textAlign: 'right',
  },
  dropdownList: {
    position: 'absolute',
    top: '100%',
    right: 0,
    left: 0,
    borderWidth: 1,
    borderRadius: 10,
    zIndex: 10,
    marginTop: 4,
  },
  dropdownItem: {
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderBottomWidth: 0.5,
  },
  dropdownItemText: {
    fontSize: 15,
    textAlign: 'right',
  },
  errorText: {
    fontSize: 12,
    marginTop: 4,
  },
});
