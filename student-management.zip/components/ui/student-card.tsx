import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';
import type { Student } from '@/data/types';

interface StudentCardProps {
  student: Student;
  onPress?: () => void;
}

export default function StudentCard({ student, onPress }: StudentCardProps) {
  const colors = useColors();

  return (
    <Pressable
      style={[
        styles.card,
        { backgroundColor: colors.surface },
      ]}
      onPress={onPress}
      android_ripple={{ color: colors.primary + '20' }}
    >
      <View style={styles.header}>
        <View style={styles.idBadge}>
          <Text style={[styles.idNumber, { color: '#FFF' }]}>#{student.id}</Text>
        </View>
        <Text style={[styles.name, { color: colors.foreground }]}>{student.name}</Text>
        <MaterialIcons name="chevron-left" size={20} color={colors.muted} />
      </View>
      
      <View style={styles.details}>
        <DetailRow icon="badge" label="الهوية" value={student.idNumber} />
        <DetailRow icon="location-on" label="المحافظة" value={student.governorate} />
        <DetailRow icon="school" label="التخصص" value={student.specialization} />
        <DetailRow icon="class" label="المستوى" value={student.level} />
        <DetailRow icon="phone" label="الهاتف" value={student.phone} />
      </View>
    </Pressable>
  );
}

function DetailRow({ icon, label, value }: { icon: string; label: string; value: string }) {
  const colors = useColors();
  return (
    <View style={styles.detailRow}>
      <MaterialIcons name={icon as any} size={18} color={colors.primary} />
      <Text style={[styles.detailLabel, { color: colors.muted }]}>{label}:</Text>
      <Text style={[styles.detailValue, { color: colors.foreground }]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    marginHorizontal: 4,
    marginVertical: 6,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 10,
  },
  idBadge: {
    backgroundColor: '#1A3A6B',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  idNumber: {
    fontSize: 12,
    fontWeight: '700',
  },
  name: {
    fontSize: 17,
    fontWeight: '700',
    flex: 1,
    textAlign: 'right',
  },
  details: {
    gap: 6,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailLabel: {
    fontSize: 13,
    flex: 0.5,
    textAlign: 'right',
  },
  detailValue: {
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
    textAlign: 'right',
  },
});
