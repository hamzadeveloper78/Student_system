import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { useColors } from '@/hooks/use-colors';
import MaterialIcons from '@expo/vector-icons/MaterialIcons';

interface ToastProps {
  visible: boolean;
  message: string;
  type: 'success' | 'error' | 'info';
  onHide: () => void;
}

export default function Toast({ visible, message, type, onHide }: ToastProps) {
  const colors = useColors();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-20)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(translateY, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();

      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 0,
            duration: 300,
            useNativeDriver: true,
          }),
          Animated.timing(translateY, {
            toValue: -20,
            duration: 300,
            useNativeDriver: true,
          }),
        ]).start(() => {
          onHide();
        });
      }, 2500);

      return () => clearTimeout(timer);
    }
  }, [visible]);

  if (!visible) return null;

  const bgColors = {
    success: colors.success + '20',
    error: colors.error + '20',
    info: colors.primary + '20',
  };

  const iconColors = {
    success: colors.success,
    error: colors.error,
    info: colors.primary,
  };

  const icons = {
    success: 'check-circle' as const,
    error: 'error' as const,
    info: 'info' as const,
  };

  return (
    <Animated.View
      style={[
        styles.container,
        {
          backgroundColor: bgColors[type],
          opacity: fadeAnim,
          transform: [{ translateY }],
        },
      ]}
    >
      <MaterialIcons name={icons[type]} size={22} color={iconColors[type]} />
      <Text style={[styles.message, { color: colors.foreground }]}>{message}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 60,
    left: 20,
    right: 20,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
    padding: 14,
    borderRadius: 12,
    zIndex: 100,
    elevation: 5,
  },
  message: {
    fontSize: 15,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
});
