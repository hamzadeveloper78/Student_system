import type { Student } from './types';

// إنشاء محتوى HTML لـ PDF
export function generatePDFHtml(students: Student[]): string {
  const date = new Date().toLocaleDateString('ar-EG', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const rows = students.map((s, i) => `
    <tr>
      <td>${i + 1}</td>
      <td>${s.name}</td>
      <td>${s.idNumber}</td>
      <td>${s.governorate}</td>
      <td>${s.specialization}</td>
      <td>${s.level}</td>
      <td>${s.phone}</td>
    </tr>
  `).join('');

  return `
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8">
  <style>
    * { box-sizing: border-box; }
    body { 
      font-family: 'Arial', sans-serif; 
      direction: rtl;
      padding: 20px;
      color: #1A1A2E;
    }
    .header {
      text-align: center;
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 3px solid #1A3A6B;
    }
    .header h1 {
      color: #1A3A6B;
      font-size: 24px;
      margin: 0 0 5px 0;
    }
    .header .date {
      color: #6B7280;
      font-size: 14px;
    }
    .stats {
      text-align: center;
      margin-bottom: 20px;
      font-size: 16px;
      color: #1A3A6B;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    th {
      background-color: #1A3A6B;
      color: white;
      padding: 10px 8px;
      font-size: 13px;
      text-align: center;
    }
    td {
      padding: 8px;
      border: 1px solid #E5E7EB;
      font-size: 12px;
      text-align: center;
    }
    tr:nth-child(even) {
      background-color: #F5F7FA;
    }
    .footer {
      text-align: center;
      margin-top: 30px;
      font-size: 11px;
      color: #6B7280;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>نظام إدارة الطلاب</h1>
    <div class="date">تاريخ التقرير: ${date}</div>
  </div>
  <div class="stats">
    إجمالي الطلاب: ${students.length} طالب
  </div>
  <table>
    <thead>
      <tr>
        <th>م</th>
        <th>اسم الطالب</th>
        <th>رقم الهوية</th>
        <th>المحافظة</th>
        <th>التخصص</th>
        <th>المستوى</th>
        <th>رقم الهاتف</th>
      </tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>
  <div class="footer">
    تم إنشاء هذا التقرير بواسطة نظام إدارة الطلاب
  </div>
</body>
</html>`;
}

// إنشاء محتوى HTML لطالب واحد (للتعديل)
export function generateStudentCardHtml(student: Student): string {
  return `
    <div style="border: 2px solid #1A3A6B; border-radius: 12px; padding: 20px; margin: 10px; direction: rtl;">
      <h2 style="color: #1A3A6B; text-align: center; margin-bottom: 15px;">${student.name}</h2>
      <div style="font-size: 14px; line-height: 2;">
        <p><strong>الرقم التعريفي:</strong> ${student.id}</p>
        <p><strong>نوع الهوية:</strong> ${student.idType}</p>
        <p><strong>رقم الهوية:</strong> ${student.idNumber}</p>
        <p><strong>المحافظة:</strong> ${student.governorate}</p>
        <p><strong>المديرية:</strong> ${student.district}</p>
        <p><strong>القرية:</strong> ${student.village}</p>
        <p><strong>العزلة:</strong> ${student.isolation}</p>
        <p><strong>التخصص:</strong> ${student.specialization}</p>
        <p><strong>المستوى:</strong> ${student.level}</p>
        <p><strong>رقم الهاتف:</strong> ${student.phone}</p>
        <p><strong>تاريخ الإضافة:</strong> ${new Date(student.createdAt).toLocaleDateString('ar-EG')}</p>
      </div>
    </div>
  `;
}
