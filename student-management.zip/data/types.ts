export interface Student {
  id: number;
  name: string;
  idType: string;
  idNumber: string;
  governorate: string;
  district: string;
  village: string;
  isolation: string;
  specialization: string;
  level: string;
  phone: string;
  createdAt: string;
}

export type StudentFormData = Omit<Student, 'id' | 'createdAt'>;

export type IDTypeOption = 'بطاقة شخصية' | 'جواز سفر' | 'بطاقة تأمين' | 'شهادة ميلاد' | 'أخرى';

export type GovernorateOption = 
  'أمانة العاصمة' | 'عدن' | 'الحديدة' | 'تعز' | 'إب' | 'ذمار' | 'المحويت'
  | 'حضرموت' | 'شبوة' | 'بيضاء' | 'مأرب' | 'الجوف' | 'صعدة' | 'عمران'
  | 'ضالع' | 'لحج' | 'أبين' | 'المهرة' | 'سقطرى' | 'ريمه' | 'صنعاء';

export type LevelOption = 'المستوى الأول' | 'المستوى الثاني' | 'المستوى الثالث' | 'المستوى الرابع' | 'المستوى الخامس' | 'المستوى السادس' | 'المستوى السابع' | 'المستوى الثامن';

export type SpecializationOption = 
  'علوم القرآن' | 'الفقه' | 'العقيدة' | 'اللغة العربية' | 'التاريخ الإسلامي'
  | 'الحديث الشريف' | 'التفسير' | 'الفلسفة' | 'أخرى';

export interface BackupInfo {
  fileName: string;
  timestamp: string;
  studentCount: number;
  filePath?: string;
}
