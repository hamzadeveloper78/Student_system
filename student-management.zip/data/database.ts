import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Student } from './types';

const STORAGE_KEY = '@students_db';
const BACKUP_KEY = '@backup_metadata';

export class DatabaseService {
  // إنشاء رقم تعريفي تلقائي
  static generateId(): number {
    return Date.now();
  }

  // الحصول على جميع الطلاب
  static async getAllStudents(): Promise<Student[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEY);
      if (!data) return [];
      return JSON.parse(data) as Student[];
    } catch (error) {
      console.error('Error getting students:', error);
      return [];
    }
  }

  // الحصول على طالب بالرقم
  static async getStudentById(id: number): Promise<Student | null> {
    try {
      const students = await this.getAllStudents();
      return students.find(s => s.id === id) || null;
    } catch (error) {
      console.error('Error getting student by id:', error);
      return null;
    }
  }

  // إضافة طالب
  static async addStudent(student: Omit<Student, 'id' | 'createdAt'>): Promise<Student> {
    try {
      const students = await this.getAllStudents();
      const newStudent: Student = {
        ...student,
        id: this.generateId(),
        createdAt: new Date().toISOString(),
      };
      students.push(newStudent);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(students));
      return newStudent;
    } catch (error) {
      console.error('Error adding student:', error);
      throw error;
    }
  }

  // تحديث طالب
  static async updateStudent(id: number, updates: Partial<Student>): Promise<Student | null> {
    try {
      const students = await this.getAllStudents();
      const index = students.findIndex(s => s.id === id);
      if (index === -1) return null;
      
      students[index] = { ...students[index], ...updates };
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(students));
      return students[index];
    } catch (error) {
      console.error('Error updating student:', error);
      throw error;
    }
  }

  // حذف طالب
  static async deleteStudent(id: number): Promise<boolean> {
    try {
      const students = await this.getAllStudents();
      const filtered = students.filter(s => s.id !== id);
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
      return true;
    } catch (error) {
      console.error('Error deleting student:', error);
      throw error;
    }
  }

  // البحث عن الطلاب
  static async searchStudents(query: string): Promise<Student[]> {
    try {
      const students = await this.getAllStudents();
      const lowerQuery = query.toLowerCase();
      return students.filter(s => 
        s.name.toLowerCase().includes(lowerQuery) ||
        s.idNumber.toLowerCase().includes(lowerQuery)
      );
    } catch (error) {
      console.error('Error searching students:', error);
      return [];
    }
  }

  // إنشاء نسخة احتياطية
  static async createBackup(): Promise<string> {
    try {
      const students = await this.getAllStudents();
      const backupData = {
        version: '1.0',
        timestamp: new Date().toISOString(),
        count: students.length,
        data: students,
      };
      const backupString = JSON.stringify(backupData, null, 2);
      await AsyncStorage.setItem(BACKUP_KEY, JSON.stringify({
        fileName: `backup_${new Date().toISOString().replace(/[:.]/g, '-')}.json`,
        timestamp: backupData.timestamp,
        studentCount: backupData.count,
      }));
      return backupString;
    } catch (error) {
      console.error('Error creating backup:', error);
      throw error;
    }
  }

  // استعادة من نسخة احتياطية
  static async restoreBackup(backupJson: string): Promise<number> {
    try {
      const backupData = JSON.parse(backupJson);
      if (!backupData.data || !Array.isArray(backupData.data)) {
        throw new Error('ملف النسخة الاحتياطية غير صالح');
      }
      const students = backupData.data as Student[];
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(students));
      return students.length;
    } catch (error) {
      console.error('Error restoring backup:', error);
      throw error;
    }
  }

  // إعادة تعيين قاعدة البيانات (للاختبار)
  static async resetDatabase(): Promise<void> {
    await AsyncStorage.removeItem(STORAGE_KEY);
    await AsyncStorage.removeItem(BACKUP_KEY);
  }
}
