/** @type {const} */
const themeColors = {
  primary: { light: '#1A3A6B', dark: '#3B5998' },
  background: { light: '#F5F7FA', dark: '#0D1117' },
  surface: { light: '#FFFFFF', dark: '#161B22' },
  foreground: { light: '#1A1A2E', dark: '#E6EDF3' },
  muted: { light: '#6B7280', dark: '#8B949E' },
  border: { light: '#E5E7EB', dark: '#30363D' },
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
  accent: { light: '#D4A843', dark: '#F0C040' },
};

module.exports = { themeColors };
