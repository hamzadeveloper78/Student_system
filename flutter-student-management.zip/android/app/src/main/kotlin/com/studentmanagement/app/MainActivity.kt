package com.studentmanagement.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
