# نظام إدارة الطلاب

تطبيق Flutter لإدارة بيانات الطلاب يعمل بدون اتصال بالإنترنت مع قاعدة بيانات محلية SQLite.

## المميزات

- إضافة طلاب جدد مع جميع البيانات
- البحث عن الطلاب بالاسم أو رقم الهوية
- تعديل وحذف بيانات الطلاب
- عرض جميع الطلاب مع تصدير ملف PDF
- مشاركة ملفات PDF
- إنشاء نسخ احتياطية واستعادتها
- واجهة عربية بالكامل مع دعم RTL

## المتطلبات

- Flutter SDK 3.0+
- Dart SDK 3.0+
- Android SDK (لبناء APK)

## التثبيت والتشغيل

```bash
# تثبيت المكتبات
flutter pub get

# تشغيل التطبيق
flutter run

# بناء APK
flutter build apk --release
```

## هيكل المشروع

```
lib/
├── main.dart                  ← نقطة البداية
├── models/
│   └── student.dart           ← نموذج بيانات الطالب
├── database/
│   └── database_helper.dart   ← خدمة قاعدة البيانات SQLite
├── services/
│   └── pdf_service.dart       ← خدمة تصدير PDF
├── widgets/
│   ├── custom_text_field.dart ← حقل إدخال مخصص
│   ├── custom_dropdown.dart   ← قائمة منسدلة مخصصة
│   └── student_card.dart      ← بطاقة عرض الطالب
└── pages/
    ├── home_page.dart         ← الشاشة الرئيسية
    ├── add_student_page.dart  ← إضافة طالب
    ├── search_student_page.dart ← بحث وتعديل وحذف
    ├── students_list_page.dart ← عرض الطلاب + PDF
    └── backup_page.dart       ← نسخ احتياطي
```

## قاعدة البيانات

| الحقل | الوصف |
|-------|-------|
| id | رقم الطالب (تلقائي) |
| name | اسم الطالب |
| idType | نوع الهوية |
| idNumber | رقم الهوية |
| governorate | المحافظة |
| district | المديرية |
| village | القرية |
| isolation | العزلة |
| specialization | التخصص |
| level | المستوى |
| phone | رقم التلفون |
| createdAt | تاريخ الإضافة |

## المكتبات المستخدمة

- `sqflite` - قاعدة بيانات SQLite المحلية
- `path_provider` - مسارات الملفات
- `pdf` + `printing` - إنشاء ومعاينة ملفات PDF
- `share_plus` - مشاركة الملفات
- `flutter_localizations` - دعم اللغة العربية
- `intl` - تنسيق التواريخ والأرقام
