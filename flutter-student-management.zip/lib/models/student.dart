class Student {
  final int? id;
  final String name;
  final String idType;
  final String idNumber;
  final String governorate;
  final String district;
  final String village;
  final String isolation;
  final String specialization;
  final String level;
  final String phone;
  final String? createdAt;

  Student({
    this.id,
    required this.name,
    this.idType = '',
    required this.idNumber,
    this.governorate = '',
    this.district = '',
    this.village = '',
    this.isolation = '',
    this.specialization = '',
    this.level = '',
    this.phone = '',
    this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'idType': idType,
      'idNumber': idNumber,
      'governorate': governorate,
      'district': district,
      'village': village,
      'isolation': isolation,
      'specialization': specialization,
      'level': level,
      'phone': phone,
      'createdAt': createdAt,
    };
  }

  factory Student.fromMap(Map<String, dynamic> map) {
    return Student(
      id: map['id'] as int?,
      name: map['name'] as String,
      idType: map['idType'] as String? ?? '',
      idNumber: map['idNumber'] as String,
      governorate: map['governorate'] as String? ?? '',
      district: map['district'] as String? ?? '',
      village: map['village'] as String? ?? '',
      isolation: map['isolation'] as String? ?? '',
      specialization: map['specialization'] as String? ?? '',
      level: map['level'] as String? ?? '',
      phone: map['phone'] as String? ?? '',
      createdAt: map['createdAt'] as String?,
    );
  }
}
