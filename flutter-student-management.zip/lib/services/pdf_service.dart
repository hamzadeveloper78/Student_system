import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../models/student.dart';

class PdfService {
  static pw.Document generateStudentsPdf(List<Student> students) {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return [
            _buildHeader(),
            pw.SizedBox(height: 20),
            _buildStatsTable(students),
            pw.SizedBox(height: 20),
            _buildStudentsTable(students),
          ];
        },
      ),
    );

    return pdf;
  }

  static pw.Widget _buildHeader() {
    return pw.Container(
      padding: pw.EdgeInsets.all(20),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromHex('#1A3A6B'),
        borderRadius: pw.BorderRadius.circular(10),
      ),
      child: pw.Column(
        children: [
          pw.Text(
            'نظام إدارة الطلاب',
            style: pw.TextStyle(
              fontSize: 24,
              fontWeight: pw.FontWeight.bold,
              color: PdfColors.white,
            ),
            textAlign: pw.TextAlign.center,
          ),
          pw.SizedBox(height: 5),
          pw.Text(
            'تقرير الطلاب المسجلين',
            style: pw.TextStyle(
              fontSize: 14,
              color: PdfColors.white,
            ),
            textAlign: pw.TextAlign.center,
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildStatsTable(List<Student> students) {
    return pw.Container(
      padding: pw.EdgeInsets.all(15),
      decoration: pw.BoxDecoration(
        color: PdfColor.fromHex('#F0F7FF'),
        border: pw.Border.all(color: PdfColor.fromHex('#1A3A6B')),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceEvenly,
        children: [
          _statItem('عدد الطلاب', '${students.length}'),
          _statItem('المحافظات', '${students.map((s) => s.governorate).toSet().length}'),
          _statItem('التخصصات', '${students.map((s) => s.specialization).toSet().length}'),
        ],
      ),
    );
  }

  static pw.Widget _statItem(String label, String value) {
    return pw.Column(
      children: [
        pw.Text(
          value,
          style: pw.TextStyle(
            fontSize: 22,
            fontWeight: pw.FontWeight.bold,
            color: PdfColor.fromHex('#1A3A6B'),
          ),
        ),
        pw.SizedBox(height: 4),
        pw.Text(
          label,
          style: pw.TextStyle(
            fontSize: 12,
            color: PdfColors.grey700,
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildStudentsTable(List<Student> students) {
    return pw.Table(
      border: pw.TableBorder.all(color: PdfColor.fromHex('#E0E0E0')),
      columnWidths: const <int, pw.TableColumnWidth>{
        0: pw.FlexColumnWidth(0.8),
        1: pw.FlexColumnWidth(2),
        2: pw.FlexColumnWidth(1.2),
        3: pw.FlexColumnWidth(1.2),
        4: pw.FlexColumnWidth(1),
        5: pw.FlexColumnWidth(1),
        6: pw.FlexColumnWidth(1.2),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(
            color: PdfColors.grey200,
          ),
          children: [
            _headerCell('رقم الطالب'),
            _headerCell('الاسم'),
            _headerCell('الهوية'),
            _headerCell('المحافظة'),
            _headerCell('التخصص'),
            _headerCell('المستوى'),
            _headerCell('الهاتف'),
          ],
        ),
        ...students.asMap().entries.map((entry) {
          final index = entry.key;
          final student = entry.value;
          return pw.TableRow(
            decoration: pw.BoxDecoration(
              color: index % 2 == 0 ? PdfColors.white : PdfColor.fromHex('#F8F9FA'),
            ),
            children: [
              _cell('#${student.id ?? index + 1}'),
              _cell(student.name),
              _cell(student.idNumber),
              _cell(student.governorate),
              _cell(student.specialization),
              _cell(student.level),
              _cell(student.phone),
            ],
          );
        }),
      ],
    );
  }

  static pw.Widget _headerCell(String text) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: const pw.TextStyle(
          fontWeight: pw.FontWeight.bold,
          fontSize: 11,
        ),
        textAlign: pw.TextAlign.center,
      ),
    );
  }

  static pw.Widget _cell(String text) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(
        text,
        style: const pw.TextStyle(fontSize: 10),
        textAlign: pw.TextAlign.center,
      ),
    );
  }
}
