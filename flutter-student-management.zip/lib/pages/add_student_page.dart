import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../database/database_helper.dart';
import '../models/student.dart';
import '../widgets/custom_text_field.dart';
import '../widgets/custom_dropdown.dart';

class AddStudentPage extends StatefulWidget {
  const AddStudentPage({super.key});

  @override
  State<AddStudentPage> createState() => _AddStudentPageState();
}

class _AddStudentPageState extends State<AddStudentPage> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final _nameController = TextEditingController();
  final _idNumberController = TextEditingController();
  final _governorateController = TextEditingController();
  final _districtController = TextEditingController();
  final _villageController = TextEditingController();
  final _isolationController = TextEditingController();
  final _specializationController = TextEditingController();
  final _levelController = TextEditingController();
  final _phoneController = TextEditingController();

  String _selectedIdType = '';
  bool _isSubmitting = false;

  // Options
  final List<String> _idTypes = [
    'بطاقة شخصية',
    'جواز سفر',
    'شهادة ميلاد',
    'أخرى',
  ];

  final List<String> _governorates = [
    'صنعاء',
    'عدن',
    'تعز',
    'الحديدة',
    'إب',
    'ذمار',
    'مأرب',
    'حجة',
    'عمران',
    'صعدة',
    'أبين',
    'شبوة',
    'حضرموت',
    'البيضاء',
    'المحويت',
    'ريمه',
    'ضالع',
    'لحج',
    'المهرة',
    'سقطرى',
    'أخرى',
  ];

  final List<String> _levels = [
    'الأول',
    'الثاني',
    'الثالث',
    'الرابع',
    'الخامس',
    'السادس',
    'السابع',
    'الثامن',
    'التاسع',
    'أخرى',
  ];

  Future<void> _saveStudent() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSubmitting = true);

    try {
      final student = Student(
        name: _nameController.text.trim(),
        idType: _selectedIdType,
        idNumber: _idNumberController.text.trim(),
        governorate: _governorateController.text.trim(),
        district: _districtController.text.trim(),
        village: _villageController.text.trim(),
        isolation: _isolationController.text.trim(),
        specialization: _specializationController.text.trim(),
        level: _levelController.text.trim(),
        phone: _phoneController.text.trim(),
      );

      await DatabaseHelper.instance.insertStudent(student);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.check_circle, color: Colors.white),
                SizedBox(width: 8),
                Text('تم حفظ الطالب بنجاح'),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
          ),
        );
        _clearFields();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Row(
              children: [
                Icon(Icons.error_outline, color: Colors.white),
                SizedBox(width: 8),
                Text('حدث خطأ أثناء الحفظ'),
              ],
            ),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _clearFields() {
    _nameController.clear();
    _idNumberController.clear();
    _governorateController.clear();
    _districtController.clear();
    _villageController.clear();
    _isolationController.clear();
    _specializationController.clear();
    _levelController.clear();
    _phoneController.clear();
    setState(() => _selectedIdType = '');
    _formKey.currentState?.reset();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _idNumberController.dispose();
    _governorateController.dispose();
    _districtController.dispose();
    _villageController.dispose();
    _isolationController.dispose();
    _specializationController.dispose();
    _levelController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة طالب جديد'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Section Title
                Row(
                  children: [
                    Icon(
                      Icons.person_add_rounded,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'بيانات الطالب',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Theme.of(context).colorScheme.onSurface,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Name
                CustomTextField(
                  label: 'اسم الطالب',
                  hint: 'أدخل اسم الطالب الثلاثي',
                  controller: _nameController,
                  required: true,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'يرجى إدخال اسم الطالب';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // ID Type
                CustomDropdown(
                  label: 'نوع الهوية',
                  hint: 'اختر نوع الهوية',
                  value: _selectedIdType,
                  items: _idTypes,
                  onChanged: (val) => setState(() => _selectedIdType = val ?? ''),
                ),
                const SizedBox(height: 16),

                // ID Number
                CustomTextField(
                  label: 'رقم الهوية',
                  hint: 'أدخل رقم الهوية',
                  controller: _idNumberController,
                  required: true,
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'يرجى إدخال رقم الهوية';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                // Governorate
                CustomDropdown(
                  label: 'المحافظة',
                  hint: 'اختر المحافظة',
                  items: _governorates,
                  onChanged: (val) => _governorateController.text = val ?? '',
                ),
                const SizedBox(height: 16),

                // District
                CustomTextField(
                  label: 'المديرية',
                  hint: 'أدخل اسم المديرية',
                  controller: _districtController,
                ),
                const SizedBox(height: 16),

                // Village
                CustomTextField(
                  label: 'القرية',
                  hint: 'أدخل اسم القرية',
                  controller: _villageController,
                ),
                const SizedBox(height: 16),

                // Isolation
                CustomTextField(
                  label: 'العزلة',
                  hint: 'أدخل اسم العزلة',
                  controller: _isolationController,
                ),
                const SizedBox(height: 16),

                // Specialization
                CustomTextField(
                  label: 'التخصص',
                  hint: 'أدخل التخصص',
                  controller: _specializationController,
                ),
                const SizedBox(height: 16),

                // Level
                CustomDropdown(
                  label: 'المستوى',
                  hint: 'اختر المستوى',
                  items: _levels,
                  onChanged: (val) => _levelController.text = val ?? '',
                ),
                const SizedBox(height: 16),

                // Phone
                CustomTextField(
                  label: 'رقم التلفون',
                  hint: 'أدخل رقم التلفون',
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                ),
                const SizedBox(height: 24),

                // Buttons
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _isSubmitting ? null : _saveStudent,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.primary,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: _isSubmitting
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2,
                                ),
                              )
                            : const Text('حفظ الطالب', style: TextStyle(fontSize: 16)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: _clearFields,
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text('مسح الحقول', style: TextStyle(fontSize: 16)),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
