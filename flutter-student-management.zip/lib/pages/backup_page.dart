import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../database/database_helper.dart';
import '../models/student.dart';

class BackupPage extends StatefulWidget {
  const BackupPage({super.key});

  @override
  State<BackupPage> createState() => _BackupPageState();
}

class _BackupPageState extends State<BackupPage> {
  int _studentCount = 0;
  bool _isCreating = false;
  bool _isRestoring = false;
  String? _lastBackupInfo;

  @override
  void initState() {
    super.initState();
    _loadCount();
  }

  Future<void> _loadCount() async {
    final students = await DatabaseHelper.instance.getAllStudents();
    if (mounted) {
      setState(() => _studentCount = students.length);
    }
  }

  Future<void> _createBackup() async {
    setState(() => _isCreating = true);

    try {
      final backupPath = await DatabaseHelper.instance.createBackup();
      final file = File(backupPath);
      
      if (mounted) {
        setState(() {
          _lastBackupInfo = 'تم إنشاء نسخة احتياطية - ${DateTime.now().toString().split('.')[0]}';
          _isCreating = false;
        });

        // Share backup file
        await Share.shareXFiles(
          [XFile(backupPath)],
          text: 'نسخة احتياطية من نظام إدارة الطلاب',
        );

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white),
                const SizedBox(width: 8),
                Text('تم إنشاء النسخة الاحتياطية بنجاح ($_studentCount طالب)'),
              ],
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            margin: const EdgeInsets.all(16),
          ),
        );

        await _loadCount();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isCreating = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('حدث خطأ أثناء إنشاء النسخة الاحتياطية'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Future<void> _importBackup() async {
    // Show file picker dialog
    final directory = await getApplicationDocumentsDirectory();
    final dir = Directory(directory.path);
    final files = await dir
        .list()
        .where((f) => f.path.endsWith('.json') && f.path.contains('backup'))
        .toList();

    if (mounted) {
      if (files.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('لا توجد نسخ احتياطية في الجهاز'),
            backgroundColor: Colors.orange,
            behavior: SnackBarBehavior.floating,
          ),
        );
        return;
      }

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        builder: (context) => StatefulBuilder(
          builder: (ctx, setState) => Container(
            padding: const EdgeInsets.all(20),
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(ctx).size.height * 0.6,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        'اختر النسخة الاحتياطية',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(ctx).colorScheme.onSurface,
                        ),
                        textAlign: TextAlign.right,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: ListView.builder(
                    itemCount: files.length,
                    itemBuilder: (ctx, index) {
                      final file = files[index] as File;
                      final fileName = file.path.split('/').last;
                      final date = DateTime.fromMillisecondsSinceEpoch(
                        int.parse(fileName.split('_').last.replaceAll('.json', '')),
                      );

                      return ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.backup, color: Colors.orange),
                        title: Text(
                          'نسخة ${date.year}/${date.month}/${date.day} - ${date.hour}:${date.minute}',
                          textAlign: TextAlign.right,
                        ),
                        subtitle: Text(
                          fileName,
                          textAlign: TextAlign.right,
                          style: TextStyle(color: Colors.grey.shade600),
                        ),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                        onTap: () async {
                          Navigator.pop(ctx);
                          await _confirmRestore(file.path, ctx);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }
  }

  Future<void> _confirmRestore(String filePath, BuildContext ctx) async {
    final confirmed = await showDialog<bool>(
      context: ctx,
      builder: (context) => AlertDialog(
        title: const Text('تأكيد الاستعادة'),
        content: const Text(
          'سيتم استبدال جميع البيانات الحالية بالبيانات من النسخة الاحتياطية. هل أنت متأكد؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('استعادة', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => _isRestoring = true);
      try {
        final count = await DatabaseHelper.instance.restoreBackup(filePath);
        if (mounted) {
          setState(() => _isRestoring = false);
          await _loadCount();
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.white),
                  const SizedBox(width: 8),
                  Text('تم استعادة $count طالب بنجاح'),
                ],
              ),
              backgroundColor: Colors.green,
              behavior: SnackBarBehavior.floating,
              margin: const EdgeInsets.all(16),
            ),
          );
        }
      } catch (e) {
        if (mounted) {
          setState(() => _isRestoring = false);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('حدث خطأ أثناء استعادة النسخة الاحتياطية'),
              backgroundColor: Colors.red,
              behavior: SnackBarBehavior.floating,
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('النسخ الاحتياطي'),
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Stats Card
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Text(
                              '$_studentCount',
                              style: TextStyle(
                                fontSize: 36,
                                fontWeight: FontWeight.bold,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'طالب مسجل في النظام',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(
                        Icons.storage_rounded,
                        size: 48,
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // Last Backup Info
              if (_lastBackupInfo != null)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade200),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          _lastBackupInfo!,
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.green.shade700,
                          ),
                          textAlign: TextAlign.right,
                        ),
                      ),
                      Icon(Icons.check_circle, color: Colors.green.shade600, size: 20),
                    ],
                  ),
                ),

              const SizedBox(height: 20),

              // Actions
              _actionCard(
                context,
                title: 'إنشاء نسخة احتياطية',
                subtitle: 'حفظ جميع بيانات الطلاب في ملف',
                icon: Icons.cloud_upload_rounded,
                iconColor: const Color(0xFF10B981),
                bgColor: const Color(0xFF10B981).withOpacity(0.15),
                onTap: _isCreating ? null : _createBackup,
                isLoading: _isCreating,
              ),

              const SizedBox(height: 14),

              _actionCard(
                context,
                title: 'استيراد نسخة احتياطية',
                subtitle: 'استعادة البيانات من ملف نسخة احتياطية',
                icon: Icons.cloud_download_rounded,
                iconColor: const Color(0xFF3B82F6),
                bgColor: const Color(0xFF3B82F6).withOpacity(0.15),
                onTap: _isRestoring ? null : _importBackup,
                isLoading: _isRestoring,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _actionCard(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Color iconColor,
    required Color bgColor,
    required VoidCallback? onTap,
    required bool isLoading,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.grey.shade200, width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: bgColor,
                borderRadius: BorderRadius.circular(20),
              ),
              child: isLoading
                  ? const SizedBox(
                      height: 30,
                      width: 30,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : Icon(icon, size: 36, color: iconColor),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 13,
                color: Colors.grey.shade600,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
