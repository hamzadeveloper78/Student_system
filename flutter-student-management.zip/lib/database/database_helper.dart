import 'dart:convert';
import 'dart:io';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import '../models/student.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  
  Database? _database;
  
  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('students.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getApplicationDocumentsDirectory();
    final path = '${dbPath.path}/$filePath';
    
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future<void> _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        idType TEXT,
        idNumber TEXT NOT NULL,
        governorate TEXT,
        district TEXT,
        village TEXT,
        isolation TEXT,
        specialization TEXT,
        level TEXT,
        phone TEXT,
        createdAt TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');
  }

  // إضافة طالب
  Future<int> insertStudent(Student student) async {
    final db = await database;
    return await db.insert('students', student.toMap());
  }

  // الحصول على جميع الطلاب
  Future<List<Student>> getAllStudents() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'students',
      orderBy: 'createdAt DESC',
    );
    return List.generate(maps.length, (i) => Student.fromMap(maps[i]));
  }

  // البحث عن طالب
  Future<List<Student>> searchStudents(String query) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'students',
      where: 'name LIKE ? OR idNumber LIKE ? OR phone LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'createdAt DESC',
    );
    return List.generate(maps.length, (i) => Student.fromMap(maps[i]));
  }

  // تحديث طالب
  Future<int> updateStudent(Student student) async {
    final db = await database;
    return await db.update(
      'students',
      student.toMap(),
      where: 'id = ?',
      whereArgs: [student.id],
    );
  }

  // حذف طالب
  Future<int> deleteStudent(int id) async {
    final db = await database;
    return await db.delete(
      'students',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // الحصول على طالب واحد
  Future<Student?> getStudent(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'students',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isNotEmpty) {
      return Student.fromMap(maps.first);
    }
    return null;
  }

  // إنشاء نسخة احتياطية
  Future<String> createBackup() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('students');
    final backupData = jsonEncode(maps);
    
    final directory = await getApplicationDocumentsDirectory();
    final backupPath = '${directory.path}/student_backup_${DateTime.now().millisecondsSinceEpoch}.json';
    
    await File(backupPath).writeAsString(backupData);
    return backupPath;
  }

  // استعادة نسخة احتياطية
  Future<int> restoreBackup(String filePath) async {
    final file = File(filePath);
    if (!await file.exists()) {
      throw Exception('ملف النسخة الاحتياطية غير موجود');
    }
    
    final content = await file.readAsString();
    final List<dynamic> data = jsonDecode(content);
    
    final db = await database;
    
    // حذف جميع البيانات الحالية
    await db.delete('students');
    
    // إدراج البيانات من النسخة الاحتياطية
    int count = 0;
    await db.transaction((txn) async {
      for (var item in data) {
        await txn.insert('students', Map<String, dynamic>.from(item));
        count++;
      }
    });
    
    return count;
  }

  // إغلاق قاعدة البيانات
  Future<void> close() async {
    final db = await database;
    db.close();
  }

  Future<void> initializeDatabase() async {
    await database;
  }
}
